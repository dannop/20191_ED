#ifndef LISTA_CLIENTES_H
#define LISTA_CLIENTES_H

#include "cliente.h"

/***
 * ESSE ARQUIVO EH USADO APENAS NOS TESTES AUTOMATIZADOS
 */

typedef struct ListaClientes {
	TCliente **lista;
	int qtd;
} TListaClientes;

// Imprime clientes
void imprime_clientes(TListaClientes *lc);

// Cria lista de clientes. Lembrar de usar libera_clientes(lista_clientes)
TListaClientes *cria_clientes(int qtd, ...);

// Salva lista de clientes no arquivo nome_arquivo
void salva_clientes(char *nome_arquivo, TListaClientes *lc);

// Le lista de clientes do arquivo nome_arquivo
TListaClientes *le_clientes(char *nome_arquivo);

// Compara duas listas de clientes
// Retorna 1 se os clientes das duas listas forem iguais
// e 0 caso contrario
int cmp_clientes(TListaClientes *c1, TListaClientes *c2);

// Desaloca lista de clientes
void libera_clientes(TListaClientes *lc);

#endif